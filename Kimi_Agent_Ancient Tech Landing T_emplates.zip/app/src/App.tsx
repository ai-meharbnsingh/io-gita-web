import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MinimalHero } from './sections/MinimalHero';
import { VerseSectionMinimal } from './sections/VerseSectionMinimal';
import { NumbersSection } from './sections/NumbersSection';
import { HowItWorksMinimal } from './sections/HowItWorksMinimal';
import { MinimalFooter } from './sections/MinimalFooter';
import { MinimalWorkingPage } from './sections/MinimalWorkingPage';

function App() {
  const [showWorkingPage, setShowWorkingPage] = useState(false);

  return (
    <AnimatePresence mode="wait">
      {showWorkingPage ? (
        <motion.div
          key="working"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          <MinimalWorkingPage onBack={() => setShowWorkingPage(false)} />
        </motion.div>
      ) : (
        <motion.div
          key="landing"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="min-h-screen bg-[#FAFAF8]"
        >
          <MinimalHero onBegin={() => setShowWorkingPage(true)} />
          <VerseSectionMinimal />
          <NumbersSection />
          <HowItWorksMinimal onBegin={() => setShowWorkingPage(true)} />
          <MinimalFooter />
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default App;
