import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ManuscriptHero } from './sections/ManuscriptHero';
import { VerseSection } from './sections/VerseSection';
import { ThreePillarsSection } from './sections/ThreePillarsSection';
import { ScienceSection } from './sections/ScienceSection';
import { TerminalCTA } from './sections/TerminalCTA';
import { ManuscriptFooter } from './sections/ManuscriptFooter';
import { TerminalWorkingPage } from './sections/TerminalWorkingPage';

function App() {
  const [showTerminal, setShowTerminal] = useState(false);

  return (
    <AnimatePresence mode="wait">
      {showTerminal ? (
        <motion.div
          key="terminal"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          <TerminalWorkingPage onBack={() => setShowTerminal(false)} />
        </motion.div>
      ) : (
        <motion.div
          key="manuscript"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          <ManuscriptHero onOpenManuscript={() => setShowTerminal(true)} />
          <VerseSection />
          <ThreePillarsSection />
          <ScienceSection />
          <TerminalCTA onCompute={() => setShowTerminal(true)} />
          <ManuscriptFooter />
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default App;
